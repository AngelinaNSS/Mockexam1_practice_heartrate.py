import matplotlib.pyplot as plt
import io
import base64


@app.route('/upload', methods=['POST'])
def upload_file():
    # (Existing code)
    data = pd.read_csv(file)

    # Plotting
    plt.figure(figsize=(10, 5))
    plt.plot(data['Time'], data['HeartRate'], label='Heart Rate')
    plt.title('Heart Rate Over Time')
    plt.xlabel('Time')
    plt.ylabel('Heart Rate')
    plt.legend()
    plt.grid()

    # Save plot to a BytesIO object
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.close()

    return render_template('your_template.html', plot_url=plot_url)
