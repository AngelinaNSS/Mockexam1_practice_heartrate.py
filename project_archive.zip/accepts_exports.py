from flask import Flask, request, redirect, url_for, render_template, flash
import os
import pandas as pd
from datetime import datetime, timedelta
import json
import matplotlib.pyplot as plt
import pandas as pd
import os
from flask import send_file

app = Flask(__name__)
app.secret_key = "supersecretkey"
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def get_valid_intervals(filepath):
    if filepath.endswith('.csv'):
        df = pd.read_csv(filepath)
    elif filepath.endswith('.json'):
        df = pd.read_json(filepath)
    else:
        return []

    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df = df.sort_values(by='timestamp')
    df['interval'] = df['timestamp'].diff().dt.total_seconds().div(60).fillna(2)
    valid_intervals = []
    current_interval = []

    for i in range(len(df)):
        if i == 0 or df['interval'].iloc[i] == 2:
            current_interval.append(df['timestamp'].iloc[i])
        else:
            if len(current_interval) >= 60:
                valid_intervals.append(current_interval)
            current_interval = [df['timestamp'].iloc[i]]

    if len(current_interval) >= 60:
        valid_intervals.append(current_interval)

    return valid_intervals

def extract_heart_rate_data(filepath):
    if filepath.endswith('.json'):
        with open(filepath) as f:
            data = json.load(f)

        end_time = datetime.now()
        start_time = end_time - timedelta(hours=2)

        heart_rates = []
        for entry in data:
            entry_start = datetime.fromisoformat(entry['startTimestampLocal'])
            entry_end = datetime.fromisoformat(entry['endTimestampLocal'])

            if entry_end > start_time and entry_start < end_time:
                heart_rates.extend(value[1] for value in entry['heartRateValues'] if value[1] is not None)

        return heart_rates
    return []

@app.route('/')
def index():
    return render_template('upload.html')

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return "No file part"
    file = request.files['file']
    if file.filename == '':
        return "No selected file"

    # Read the data from the uploaded CSV file
    df = pd.read_csv(file)

    # Assuming your DataFrame has a column named 'heart_rate'
    heart_rates = df['heart_rate']

    # Plotting the heart rate data
    plt.figure(figsize=(10, 5))  # Set the size of the plot
    plt.plot(heart_rates, label='Heart Rate', color='blue')  # Plot the heart rate data
    plt.title('Heart Rate Over Time')  # Title of the plot
    plt.xlabel('Time (arbitrary units)')  # X-axis label
    plt.ylabel('Heart Rate (bpm)')  # Y-axis label
    plt.legend()  # Show legend
    plt.grid()  # Add grid

    # Save the plot to a static folder
    plot_path = os.path.join('static', 'heart_rate_plot.png')
    plt.savefig(plot_path)  # Save the plot
    plt.close()  # Close the plot

    return render_template('upload.html', plot_url=plot_path)

@app.route('/data')
def list_intervals():
    files = [f for f in os.listdir(app.config['UPLOAD_FOLDER']) if f.endswith('.csv') or f.endswith('.json')]
    all_valid_intervals = []

    for file in files:
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], file)
        intervals = get_valid_intervals(filepath)
        all_valid_intervals.extend([(file, interval) for interval in intervals])

    return render_template('data.html', intervals=all_valid_intervals)

@app.route('/heart-rate')
def heart_rate():
    files = [f for f in os.listdir(app.config['UPLOAD_FOLDER']) if f.endswith('.json')]
    heart_rates = []

    for file in files:
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], file)
        heart_rates.extend(extract_heart_rate_data(filepath))

    if heart_rates:
        min_hr = min(heart_rates)
        max_hr = max(heart_rates)
        avg_hr = sum(heart_rates) / len(heart_rates)
    else:
        min_hr, max_hr, avg_hr = None, None, None

    return render_template('heart_rate.html', min_hr=min_hr, max_hr=max_hr, avg_hr=avg_hr)

if __name__ == '__main__':
    app.run(debug=True)

