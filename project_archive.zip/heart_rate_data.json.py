[
    {
        "startTimestampLocal": "2023-07-14T10:00:00",
        "endTimestampLocal": "2023-07-14T12:00:00",
        "heartRateValues": [[1678005000000, 58], [1678005240000, 68], [1678005360000, 76]]
    },
    {
        "startTimestampLocal": "2023-07-14T12:00:00",
        "endTimestampLocal": "2023-07-14T14:00:00",
        "heartRateValues": [[1678008000000, 70], [1678008120000, 75], [1678008240000, 80]]
    }
]
